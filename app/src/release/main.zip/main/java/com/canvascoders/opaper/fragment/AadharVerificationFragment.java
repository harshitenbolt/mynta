package com.canvascoders.opaper.fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.canvascoders.opaper.Beans.AadhaarCard;
import com.canvascoders.opaper.Beans.PancardVerifyResponse.CommonResponse;
import com.canvascoders.opaper.R;
import com.canvascoders.opaper.utils.ImagePicker;
import com.canvascoders.opaper.activity.AppApplication;
import com.canvascoders.opaper.activity.OTPActivity;
import com.canvascoders.opaper.activity.ScannerActivity;
import com.canvascoders.opaper.api.ApiClient;
import com.canvascoders.opaper.api.ApiInterface;
import com.canvascoders.opaper.utils.AadhaarXMLParser;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.utils.DataAttributes;
import com.canvascoders.opaper.utils.Mylogger;
import com.canvascoders.opaper.utils.RequestPermissionHandler;
import com.canvascoders.opaper.utils.SessionManager;


import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;


import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static android.app.Activity.RESULT_OK;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;


public class AadharVerificationFragment extends Fragment implements View.OnClickListener {

    private static final int IMAGE_AADHAR_FRONT = 1021;
    private static final int IMAGE_AADHAR_BACK = 1022;
    // directory name to store captured images and videos
    private static final String IMAGE_DIRECTORY_NAME = ".oppr";
    private final static int REQUEST_SCANNER = 1000;
    public String udi = "";
    public String name = "";
    public String year = "";
    public String pincode = "";
    static String TAG = "AadharVerification";
    private static int IMAGE_SELCTION_CODE = 0;
    private Button btn_next;
    private Uri imgURI;
    private String aadharImagepathFront = "";
    private String aadharImagepathBack = "";
    private SessionManager sessionManager;
    //private PermissionUtil.PermissionRequestObject mALLPermissionRequest;
    private ImageView btn_aadhar_front, btn_aadhar_back;
    private ImageView btn_aadhar_front_select, btn_aadhar_back_select;
    private boolean isAadhaarFrontSelected = false;
    private boolean isAadhaarBackSelected = false;
    Context mcontext;
    View view;
    ProgressDialog mProgressDialog;
    private TextView tv_review;
    private RequestPermissionHandler requestPermissionHandler;
    private String str_process_id;

//    private static File getOutputMediaFile(int type) {
//        File mediaStorageDir = new File(Environment.getDownloadCacheDirectory(), IMAGE_DIRECTORY_NAME);
//
//        // Create the storage directory if it does not exist
//        if (!mediaStorageDir.exists()) {
//            if (!mediaStorageDir.mkdirs()) {
//                Mylogger.getInstance().Logit(IMAGE_DIRECTORY_NAME, "Oops! Failed create "
//                        + IMAGE_DIRECTORY_NAME + " directory");
//                return null;
//            }
//        }
//
//        File mediaFile;
//        if (type == MEDIA_TYPE_IMAGE) {
//            mediaFile = new File(mediaStorageDir.getPath() + File.separator
//                    + "O_" + System.currentTimeMillis() + ".jpeg");
//        } else {
//            return null;
//        }
//
//        return mediaFile;
//    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_aadhar, container, false);

        mcontext = this.getActivity();

        requestPermissionHandler = new RequestPermissionHandler();

        initView();


        sessionManager = new SessionManager(getActivity());

        str_process_id = sessionManager.getData(Constants.KEY_PROCESS_ID);

        Log.e("process_id", "Process_id" + str_process_id);
        OTPActivity.settitle("Aadhaar Verification");

        return view;
    }


    private void initView() {

        mProgressDialog = new ProgressDialog(mcontext);
        mProgressDialog.setTitle("Please wait updating vendor details");

        btn_next = view.findViewById(R.id.btn_next);
        btn_next.setOnClickListener(this);

        btn_aadhar_front = (ImageView) view.findViewById(R.id.btn_aadhar_front);
        btn_aadhar_front_select = (ImageView) view.findViewById(R.id.btn_aadhar_front_select);
        btn_aadhar_back = (ImageView) view.findViewById(R.id.btn_aadhar_back);
        btn_aadhar_back_select = (ImageView) view.findViewById(R.id.btn_aadhar_back_select);
        tv_review = (TextView) view.findViewById(R.id.tv_review_detail);

        btn_aadhar_front.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                capture_aadhar_front_and_back_image(1);

            }
        });


        btn_aadhar_back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                capture_aadhar_front_and_back_image(2);
            }
        });

        tv_review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAadhaarBackSelected == true & isAadhaarFrontSelected == true) {
                    showEditDialog();
                }
            }
        });

    }

    private void capture_aadhar_front_and_back_image(int side_of_aadhar) {
        requestPermissionHandler.requestPermission(getActivity(), new String[]{
                Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION
        }, 123, new RequestPermissionHandler.RequestPermissionListener() {
            @Override
            public void onSuccess() {

                if (side_of_aadhar == 1) {


                    IMAGE_SELCTION_CODE = IMAGE_AADHAR_FRONT;
                    Intent chooseImageIntent = ImagePicker.getCameraIntent(getActivity());
                    startActivityForResult(chooseImageIntent, IMAGE_AADHAR_FRONT);

                }
                if (side_of_aadhar == 2) {

                    IMAGE_SELCTION_CODE = IMAGE_AADHAR_BACK;

                    Intent chooseImageIntent = ImagePicker.getCameraIntent(getActivity());
                    startActivityForResult(chooseImageIntent, IMAGE_AADHAR_BACK);
                }

                if (side_of_aadhar == 3) {

                    Intent intent = new Intent(getActivity(), ScannerActivity.class);
                    startActivityForResult(intent, REQUEST_SCANNER);
                }


            }

            @Override
            public void onFailed() {
                Toast.makeText(mcontext, "request permission failed", Toast.LENGTH_SHORT).show();

            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            getActivity().finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_next) {

            if (isAadhaarBackSelected == true & isAadhaarFrontSelected == true) {

                capture_aadhar_front_and_back_image(3);
            }
        }

    }

    private void showEditDialog() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            public void run() {
                EditNameDialogFragment editNameDialogFragment = EditNameDialogFragment.newInstance(AadharVerificationFragment.this);
                editNameDialogFragment.setCancelable(false);
                editNameDialogFragment.show(getChildFragmentManager(), "fragment_edit_name");
            }
        });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if ((requestCode == IMAGE_AADHAR_FRONT && resultCode == RESULT_OK) || (requestCode == IMAGE_AADHAR_BACK && resultCode == RESULT_OK) || requestCode == REQUEST_SCANNER && resultCode == RESULT_OK) {
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_AADHAR_FRONT) {


                Bitmap bitmap = ImagePicker.getImageFromResult(getActivity(), resultCode, data);
                aadharImagepathFront = ImagePicker.getBitmapPath(bitmap, getActivity());
                Glide.with(getActivity()).load(aadharImagepathFront).into(btn_aadhar_front);
                isAadhaarFrontSelected = true;
                btn_aadhar_front_select.setVisibility(View.VISIBLE);


                    /*Bitmap photo = (Bitmap) data.getExtras().get("data");
                    aadharImagepathFront = getRealPathFromURI(imgURI);
                    btn_aadhar_front.setImageBitmap(BitmapFactory.decodeFile(aadharImagepathFront));
                    isAadhaarFrontSelected = true;*/
                //imgURI = ImageUtils.getInstant().getImageUri(getActivity(), photo);
                //imgURI = data.getData();

                Log.e("aadharcard", "front image" + aadharImagepathFront);
                /*btn_aadhar_front_select.setVisibility(View.VISIBLE);*/


            }
            if (requestCode == IMAGE_AADHAR_BACK) {


                Bitmap bitmap = ImagePicker.getImageFromResult(getActivity(), resultCode, data);
                aadharImagepathBack = ImagePicker.getBitmapPath(bitmap, getActivity());
                Glide.with(getActivity()).load(aadharImagepathBack).into(btn_aadhar_back);
                isAadhaarBackSelected = true;
                btn_aadhar_front_select.setVisibility(View.VISIBLE);

                    /*Bitmap photo = (Bitmap) data.getExtras().get("data");
                    btn_aadhar_back.setImageBitmap(photo);
                    imgURI = ImageUtils.getInstant().getImageUri(getActivity(), photo);
                    aadharImagepathBack = ImageUtils.getInstant().getRealPathFromURI(mcontext, imgURI);*/
                Log.e("aadharcard", "back image" + aadharImagepathBack);
                    /*isAadhaarBackSelected = true;
                    btn_aadhar_back_select.setVisibility(View.VISIBLE);*/

            }
            if (requestCode == REQUEST_SCANNER && (data != null)) {
                processScannedData(data.getStringExtra(Constants.CONTENT));
            }
            setButtonImage();
        }


    }

    private void setButtonImage() {
        if (isAadhaarBackSelected == true & isAadhaarFrontSelected == true) {
            btn_next.setBackground(getResources().getDrawable(R.drawable.btn_active));
            btn_next.setEnabled(true);
            btn_next.setTextColor(getResources().getColor(R.color.colorWhite));
        }
    }


    public void ProcessData(String scanData) {
        try {

            if (scanData.contains("<?xml") || scanData.startsWith("<?xml")) {
                scanData = scanData.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>", "");
            }

            AadhaarCard newCard = new AadhaarXMLParser().parse(scanData.trim());
            Mylogger.getInstance().Logit(TAG, newCard.toString());
        } catch (XmlPullParserException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    protected void processScannedData(String scanData) {

        if (scanData != null) {
            scanData = scanData.replaceAll(Pattern.quote("</?xml version=\"1.0\" encoding=\"UTF-8\"?>"), "").trim();
        }

        Mylogger.getInstance().Logit(TAG, scanData);
        XmlPullParserFactory pullParserFactory;
        try {
            pullParserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = pullParserFactory.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(new StringReader(scanData));
            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {

                if (eventType == XmlPullParser.START_DOCUMENT) {

                } else if (eventType == XmlPullParser.START_TAG && DataAttributes.AADHAAR_DATA_TAG.equals(parser.getName())) {

                    udi = parser.getAttributeValue(null, DataAttributes.AADHAR_UID_ATTR);
                    name = parser.getAttributeValue(null, DataAttributes.AADHAR_NAME_ATTR);
                    year = parser.getAttributeValue(null, DataAttributes.AADHAR_YOB_ATTR);
                    pincode = parser.getAttributeValue(null, DataAttributes.AADHAR_PC_ATTR);

                    sessionManager.saveData(Constants.KEY_UID, udi);
                    sessionManager.saveData(Constants.KEY_AADHAR_NAME, name);
                    sessionManager.saveData(Constants.KEY_YEAR, year);
                    sessionManager.saveData(Constants.KEY_PINCODE, pincode);


                    Mylogger.getInstance().Logit(TAG, "udi: " + udi);
                    Mylogger.getInstance().Logit(TAG, "name: " + name);
                    Mylogger.getInstance().Logit(TAG, "year: " + year);
                    Mylogger.getInstance().Logit(TAG, "pincode: " + pincode);
                } else if (eventType == XmlPullParser.END_TAG) {
                } else if (eventType == XmlPullParser.TEXT) {
                }
                eventType = parser.next();
            }

        } catch (XmlPullParserException e) {
            e.printStackTrace();
            Mylogger.getInstance().Logit("XmlPullParserException", e.toString());
        } catch (IOException e) {
            e.printStackTrace();
            Mylogger.getInstance().Logit("IOException", e.toString());
        } catch (SQLiteConstraintException e) {
            Mylogger.getInstance().Logit("SQLiteConstraintException", e.toString());
        }


        showEditDialog();

    }


    public void storeAadhar() {

        MultipartBody.Part aadharcard_front_part = null;
        MultipartBody.Part aadharcard_back_part = null;

        Mylogger.getInstance().Logit(TAG, "getUserInfo");

        udi = sessionManager.getData(Constants.KEY_UID);
        name = sessionManager.getData(Constants.KEY_AADHAR_NAME);
        year = sessionManager.getData(Constants.KEY_YEAR);
        pincode = sessionManager.getData(Constants.KEY_PINCODE);


        if (AppApplication.networkConnectivity.isNetworkAvailable()) {

            Map<String, String> params = new HashMap<String, String>();

            params.put(Constants.PARAM_TOKEN, sessionManager.getToken());
            params.put(Constants.PARAM_PROCESS_ID, str_process_id);
            params.put(Constants.PARAM_AGENT_ID, sessionManager.getAgentID());
            params.put(Constants.PARAM_UID, udi.trim());
            params.put(Constants.PARAM_NAME, name.trim());
            params.put(Constants.PARAM_YEAR_OF_BIRTH, year.trim());
            params.put(Constants.PARAM_PINCODE, pincode.trim());

            File imagefile = new File(aadharImagepathFront);
            aadharcard_front_part = MultipartBody.Part.createFormData(Constants.PARAM_AADHAR_FRONT, imagefile.getName(), RequestBody.create(MediaType.parse(Constants.getMimeType(aadharImagepathFront)), imagefile));

            File imagefile1 = new File(aadharImagepathBack);
            aadharcard_back_part = MultipartBody.Part.createFormData(Constants.PARAM_AADHAR_BACK, imagefile1.getName(), RequestBody.create(MediaType.parse(Constants.getMimeType(aadharImagepathBack)), imagefile));

            Mylogger.getInstance().Logit(TAG, "getUserInfo");
            mProgressDialog.setMessage("Please wait getting details...");
            mProgressDialog.show();

            Call<CommonResponse> callUpload = ApiClient.getClient().create(ApiInterface.class).getstoreAadhar(params, aadharcard_front_part, aadharcard_back_part);
            callUpload.enqueue(new Callback<CommonResponse>() {
                @Override
                public void onResponse(Call<CommonResponse> call, retrofit2.Response<CommonResponse> response) {
                    if (mProgressDialog != null) {
                        mProgressDialog.dismiss();
                    }
                    if (response.isSuccessful()) {
                        CommonResponse getaadhardetail = response.body();


                        if (getaadhardetail.getResponseCode() == 200) {


                            if (aadharImagepathFront != null) {
                                //deleteFileFromMediaManager(getActivity(), aadharImagepathFront);
                            }
                            if (aadharImagepathBack != null) {
                                //deleteFileFromMediaManager(getActivity(), aadharImagepathBack);
                            }

                            showAlert(getaadhardetail.getResponse());

                            sessionManager.saveData(Constants.KEY_AADHAR_NAME, "");
                            sessionManager.saveData(Constants.KEY_UID, "");
                            sessionManager.saveData(Constants.KEY_PINCODE, "");
                            sessionManager.saveData(Constants.KEY_YEAR, "");


                        } else {
                            if (getaadhardetail.getResponseCode() == 405) {
                                sessionManager.logoutUser(mcontext);
                            }
                            showAlert2(getaadhardetail.getResponse());
                        }

                    } else {
                        Toast.makeText(mcontext, "No response", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(Call<CommonResponse> call, Throwable t) {
                    mProgressDialog.dismiss();

                }
            });
        } else {
            Constants.ShowNoInternet(mcontext);
        }

    }

    private void showAlert(String msg) {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mcontext);
        alertDialog.setTitle("Aadhaarcard Verification");
        alertDialog.setMessage(msg);
        alertDialog.setCancelable(false);
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                commanFragmentCallWithoutBackStack(new PanVerificationFragment());

            }
        });
        alertDialog.show();

    }

    private void showAlert2(String msg) {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mcontext);
        alertDialog.setTitle("Aadhaarcard Verification");
        alertDialog.setMessage(msg);
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertDialog.show();

    }


    public void commanFragmentCallWithoutBackStack(Fragment fragment) {

        Fragment cFragment = fragment;

        if (cFragment != null) {

            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.content_main, cFragment);
            fragmentTransaction.commit();

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        requestPermissionHandler.onRequestPermissionsResult(requestCode, permissions,
                grantResults);
    }

    /*public void deleteFileFromMediaManager(Context context, String path) {
        File file = new File(path);
        file.delete();
        if (file.exists()) {
            try {
                file.getCanonicalFile().delete();
                if (file.exists()) {
                    context.deleteFile(file.getName());
                    Log.e("Deleted File", String.valueOf(file));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }*/

}
