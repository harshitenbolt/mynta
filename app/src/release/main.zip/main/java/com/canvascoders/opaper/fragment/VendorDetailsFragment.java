package com.canvascoders.opaper.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.canvascoders.opaper.R;
import com.canvascoders.opaper.activity.StoreTypeListingActivity;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.activity.DashboardActivity;
import com.canvascoders.opaper.Beans.VendorList;

import static android.app.Activity.RESULT_OK;

public class VendorDetailsFragment extends Fragment {

    private static final int CHEQUE_UPDATE_INTENT = 1001;
    VendorList vendor;
    TextView tv_ShopName, tv_Mobile, tv_Name;
    ImageView ivVendorImage;
    Button btn_update_cheque, btn_update_store_details;


    View view;
    Context mcontext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_vendor_detail, container, false);

        mcontext = this.getActivity();

        DashboardActivity.settitle(Constants.TITLE_VENDOR_DETAIL);

        tv_ShopName = view.findViewById(R.id.tv_shop_name);
        tv_Mobile = view.findViewById(R.id.tv_mobile);
        tv_Name = view.findViewById(R.id.tv_name);
        ivVendorImage = view.findViewById(R.id.iv_vendor_image);
        btn_update_cheque = view.findViewById(R.id.btn_update_cheque);
        btn_update_store_details = view.findViewById(R.id.btn_update_store_details);

        vendor = (VendorList) getArguments().getSerializable("data");

        if (vendor != null) {

            tv_ShopName.setText(vendor.getStoreName());
            tv_Name.setText(vendor.getName());
            tv_Mobile.setText(vendor.getMobileNo());
            Glide.with(this).load(vendor.getShopImage())
                    .placeholder(R.drawable.store_place)
                    .error(R.drawable.store_place)
                    .fallback(R.drawable.store_place)
                    .into(ivVendorImage);
            Log.e("VId", "" + vendor.getVendorId() + " ::" + vendor.getName());
        }

        if (vendor.getBankDetailUpdationRequired().equalsIgnoreCase("1")) {
            btn_update_cheque.setVisibility(View.VISIBLE);
        } else {
            btn_update_cheque.setVisibility(View.GONE);
        }

        btn_update_cheque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commanFragmentCallWithBackStack(new ChequedataUpdateFragment());
            }
        });

        btn_update_store_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(mcontext, StoreTypeListingActivity.class);
                myIntent.putExtra("data", vendor);
                startActivity(myIntent);
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CHEQUE_UPDATE_INTENT && resultCode == RESULT_OK) {
        }
    }

    public void commanFragmentCallWithBackStack(Fragment fragment) {

        Fragment cFragment = fragment;

        if (cFragment != null) {


            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.content_main, cFragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
    }
}
