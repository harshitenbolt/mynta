package com.canvascoders.opaper.fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.canvascoders.opaper.R;
import com.canvascoders.opaper.utils.ImagePicker;
import com.canvascoders.opaper.activity.AppApplication;
import com.canvascoders.opaper.activity.OTPActivity;
import com.canvascoders.opaper.api.ApiClient;
import com.canvascoders.opaper.api.ApiInterface;
import com.canvascoders.opaper.Beans.PanImageResponse.PanImageResponse;
import com.canvascoders.opaper.Beans.PancardVerifyResponse.CommonResponse;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.utils.ImageUtils;
import com.canvascoders.opaper.utils.Mylogger;
import com.canvascoders.opaper.utils.RequestPermissionHandler;
import com.canvascoders.opaper.utils.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Callback;

import static android.app.Activity.RESULT_OK;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;

public class PanVerificationFragment extends Fragment implements View.OnClickListener {

    private static final int IMAGE_PAN = 101;
    private static final String IMAGE_DIRECTORY_NAME = "oppr";
    Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
    File sourceFile;
    int totalSize = 0;
    ProgressDialog pd;
    private String TAG = "PanVerification";
    private Button btn_next, btn_extract;
    private String panImagepath = "", identityType = "", identityEmail = "", identityCallbackUrl = "", identityAccessToken = "", identityID = "", identityPatronId = "";
    private Uri imgURI;
    private ImageView btn_pan_card;
    Context mcontext;
    View view;
    String str_process_id, authUserID, authCreated, authID;
    private long authTTL;


    private RequestPermissionHandler requestPermissionHandler;

    private ImageView btn_pan_card_select;
    private SessionManager sessionManager;
    private boolean isPanSelected = false;
    private EditText edit_pan_name, edit_pan_name_father, edit_pan_number;
    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (edit_pan_name.getText().toString().length() > 3 && edit_pan_name_father.getText().toString().length() > 3 && edit_pan_number.getText().toString().length() > 3) {
                setButtonImage();
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
    private String from = "individualPan";
    private JSONObject panEssentials = new JSONObject();
    private ProgressDialog mProgressDialog;

    private static File getOutputMediaFile(int type) {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), IMAGE_DIRECTORY_NAME);

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Mylogger.getInstance().Logit(IMAGE_DIRECTORY_NAME, "Oops! Failed create "
                        + IMAGE_DIRECTORY_NAME + " directory");
                return null;
            }
        }

        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator
                    + "O_" + System.currentTimeMillis() + ".jpeg");
        } else {
            return null;
        }

        return mediaFile;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_pan, container, false);

        mcontext = this.getActivity();

        sessionManager = new SessionManager(mcontext);
        str_process_id = sessionManager.getData(Constants.KEY_PROCESS_ID);
        pd = new ProgressDialog(mcontext);

        OTPActivity.settitle(Constants.TITLE_PAN_CARD_VERIFICATION);

        requestPermissionHandler = new RequestPermissionHandler();

        initView();

        return view;

    }

    private void initView() {
        btn_next = view.findViewById(R.id.btn_next);
        btn_extract = view.findViewById(R.id.btn_extract);
        btn_pan_card = (ImageView) view.findViewById(R.id.btn_pan_cards);

        btn_pan_card_select = (ImageView) view.findViewById(R.id.btn_pan_card_select);
        edit_pan_name = (EditText) view.findViewById(R.id.edit_pan_name);
        edit_pan_name_father = (EditText) view.findViewById(R.id.edit_pan_name_father);
        edit_pan_number = (EditText) view.findViewById(R.id.edit_pan_number);

        edit_pan_name.addTextChangedListener(textWatcher);
        edit_pan_name_father.addTextChangedListener(textWatcher);
        edit_pan_number.addTextChangedListener(textWatcher);

        edit_pan_name.setEnabled(false);
        edit_pan_name_father.setEnabled(false);
        edit_pan_number.setEnabled(false);

        btn_next.setOnClickListener(this);
        btn_pan_card.setOnClickListener(this);
        btn_extract.setOnClickListener(this);

    }

    private void setButtonImage() {
        if (isPanSelected == true) {
            btn_next.setBackground(getResources().getDrawable(R.drawable.btn_active));
            btn_next.setEnabled(true);
            btn_next.setTextColor(getResources().getColor(R.color.colorWhite));
        } else {
            btn_next.setBackground(getResources().getDrawable(R.drawable.btn_normal));
            btn_next.setEnabled(false);
            btn_next.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            getActivity().finish();
        }
        return super.onOptionsItemSelected(item);
    }

    //check permition
    private void capture_pan_card_image() {
        requestPermissionHandler.requestPermission(getActivity(), new String[]{
                Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
        }, 123, new RequestPermissionHandler.RequestPermissionListener() {
            @Override
            public void onSuccess() {

                Intent chooseImageIntent = ImagePicker.getCameraIntent(getActivity());
                startActivityForResult(chooseImageIntent, IMAGE_PAN);

               /* Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, IMAGE_PAN);*/
            }

            @Override
            public void onFailed() {
                Toast.makeText(mcontext, "request permission failed", Toast.LENGTH_SHORT).show();

            }
        });

    }

    //why this is not used ?
    private boolean validation() {

        if (!isPanSelected) {
            Toast.makeText(mcontext, "Please select PAN Image", Toast.LENGTH_SHORT).show();
            return false;

        }
        if (TextUtils.isEmpty(edit_pan_name.getText().toString())) {
            edit_pan_name.setError("Provide name");
            edit_pan_name.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(edit_pan_name_father.getText().toString())) {
            edit_pan_name_father.setError("Provide Father name");
            edit_pan_name_father.requestFocus();
            return false;
        }

        Matcher matcher = Constants.PAN_PATTERN.matcher(edit_pan_number.getText().toString());
        if (TextUtils.isEmpty(edit_pan_number.getText().toString()) || edit_pan_number.getText().toString().length() < 5) {
            edit_pan_number.setError("Provide Number");
            edit_pan_number.requestFocus();
            return false;
        } else if (!matcher.matches()) {
            edit_pan_number.setError("Provide Valid Pan Number");
            edit_pan_number.requestFocus();
            return false;
        }

        return true;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_next) {
            if (validation()) {
                Constants.hideKeyboardwithoutPopulate(getActivity());
                if (AppApplication.networkConnectivity.isNetworkAvailable()) {
                    storePAN();
                } else {
                    Constants.ShowNoInternet(getActivity());
                }
            }
        } else if (v.getId() == R.id.btn_pan_cards) {

            capture_pan_card_image();


        } else if (v.getId() == R.id.btn_extract) {
            try {

                if (AppApplication.networkConnectivity.isNetworkAvailable()) {
                    UploadPanFileToServer();
                } else {
                    Constants.ShowNoInternet(mcontext);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


    public Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMAGE_PAN && resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PAN) {

                Constants.hideKeyboardwithoutPopulate(getActivity());
                Bitmap bitmap = ImagePicker.getImageFromResult(getActivity(), resultCode, data);
                panImagepath = ImagePicker.getBitmapPath(bitmap, getActivity());
                Glide.with(getActivity()).load(panImagepath).into(btn_pan_card);
                isPanSelected = true;
                btn_pan_card_select.setVisibility(View.VISIBLE);
                Log.e("Pan image path",panImagepath);

                //new ResizeAsync().execute();
            }
        }

    }

    public void storePAN() {

        MultipartBody.Part pan_card_part = null;

        if (AppApplication.networkConnectivity.isNetworkAvailable()) {

            Map<String, String> params = new HashMap<String, String>();

            params.put(Constants.PARAM_TOKEN, sessionManager.getToken());
            params.put(Constants.PARAM_PROCESS_ID, str_process_id);
            params.put(Constants.PARAM_AGENT_ID, sessionManager.getAgentID());
            params.put(Constants.PARAM_PAN_NO, "" + edit_pan_number.getText());
            params.put(Constants.PARAM_PAN_NAME, "" + edit_pan_name.getText());
            params.put(Constants.PARAM_FATHER_NAME, "" + edit_pan_name_father.getText());

            File imagefile = new File(panImagepath);
            pan_card_part = MultipartBody.Part.createFormData(Constants.PARAM_PAN_CARD_FRONT, imagefile.getName(), RequestBody.create(MediaType.parse(Constants.getMimeType(panImagepath)), imagefile));

            Mylogger.getInstance().Logit(TAG, "getUserInfo");
            mProgressDialog.setMessage("Please wait getting details...");
            mProgressDialog.show();

            Call<CommonResponse> callUpload = ApiClient.getClient().create(ApiInterface.class).getstorePancard(params, pan_card_part);
            callUpload.enqueue(new Callback<CommonResponse>() {


                @Override
                public void onResponse(Call<CommonResponse> call, retrofit2.Response<CommonResponse> response) {
                    if (mProgressDialog != null) {
                        mProgressDialog.dismiss();
                    }


                    if (response.isSuccessful()) {

                        CommonResponse panVerificationDetail = response.body();

                        if (panVerificationDetail.getResponseCode() == 200) {
                            str_process_id = panVerificationDetail.getData().get(0).getProccess_id();
                            showAlert(response.body().getResponse());




                        } else {
                            Constants.showAlert(edit_pan_name.getRootView(), panVerificationDetail.getResponse(), false);

                        }
                        if (panVerificationDetail.getResponseCode() == 405) {
                            sessionManager.logoutUser(mcontext);
                        }


                    } else {
                        Toast.makeText(mcontext, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                    }

                }

                @Override
                public void onFailure(Call<CommonResponse> call, Throwable t) {
                    mProgressDialog.dismiss();

                }
            });
        } else {
            Constants.ShowNoInternet(mcontext);
        }

    }

    private void showAlert(String msg) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mcontext);
        alertDialog.setTitle("PAN Details");
        alertDialog.setMessage(msg);
        alertDialog.setCancelable(false);
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                commanFragmentCallWithoutBackStack(new ChequeUploadFragment());

            }
        });
        alertDialog.show();
    }


    public void UploadPanFileToServer() {

        MultipartBody.Part typedFile = null;
        if (!TextUtils.isEmpty(panImagepath)) {

            mProgressDialog = new ProgressDialog(mcontext);
            mProgressDialog.setMessage("Please wait, While we are uploading...");
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();

            File imagefile = new File(panImagepath);
            typedFile = MultipartBody.Part.createFormData(Constants.PARAM_PAN_CARD_FRONT, imagefile.getName(), RequestBody.create(MediaType.parse(Constants.getMimeType(panImagepath)), imagefile));//RequestBody.create(MediaType.parse("image"), new File(mProfileBitmapPath));

            Call<PanImageResponse> callUpload = ApiClient.getClient().create(ApiInterface.class).getPancardOcrUrl(sessionManager.getToken(), str_process_id, typedFile);

            callUpload.enqueue(new Callback<PanImageResponse>() {
                @Override
                public void onResponse(Call<PanImageResponse> call, retrofit2.Response<PanImageResponse> response) {
                    mProgressDialog.dismiss();

                    if (response.isSuccessful()) {
                        PanImageResponse panImageResponse = response.body();
                        if (panImageResponse.getResponseCode() == 200) {
                            String imagePath = panImageResponse.getData().get(0).getPan_url();
                            if (!TextUtils.isEmpty(imagePath)) {
                                ExtractPanDetail extractPanDetail = new ExtractPanDetail();
                                extractPanDetail.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, imagePath);
                            } else {

                            }
                        } else if (panImageResponse.getResponseCode() == 405) {
                            sessionManager.logoutUser(mcontext);
                        } else {
                            Toast.makeText(mcontext, panImageResponse.getResponse(), Toast.LENGTH_LONG).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<PanImageResponse> call, Throwable t) {
                    mProgressDialog.dismiss();
                    Toast.makeText(mcontext, t.getMessage().toString(), Toast.LENGTH_LONG).show();
                }
            });

        }
    }

    public class ResizeAsync extends AsyncTask<Void, Void, File> {

        @Override
        protected File doInBackground(Void... voids) {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            Bitmap out = ImageUtils.getInstant().getCompressedBitmap(panImagepath);

            File file = new File(dir, "pan_" + System.currentTimeMillis() + ".png");
            FileOutputStream fOut;
            try {
                fOut = new FileOutputStream(file);
                out.compress(Bitmap.CompressFormat.PNG, 100, fOut);
                fOut.flush();
                fOut.close();
                out.recycle();
            } catch (Exception e) {
            }
            return file;
        }

        @Override
        protected void onPostExecute(File file) {
            super.onPostExecute(file);
            if (file != null) {
                panImagepath = file.getPath();
                Glide.with(PanVerificationFragment.this)
                        .load(Uri.fromFile(file))
                        .placeholder(R.drawable.placeholder)
                        .into(btn_pan_card);
                //.transform(new RotateTransformation(this, 90f))
                isPanSelected = true;
                btn_pan_card_select.setVisibility(View.VISIBLE);
            }
        }
    }

    public class ExtractPanDetail extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(mcontext);
            progressDialog.setMessage("Pan card (Auto reading and verification)");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String[] params) {
            String myRes = "";
            try {
                OkHttpClient client = new OkHttpClient();
                MediaType mediaType = MediaType.parse("application/json");

                JSONObject jsonLoginCheck = new JSONObject();
                jsonLoginCheck.put(Constants.PARAM_USER_NAME, Constants.UserName);
                jsonLoginCheck.put(Constants.PARAM_PASSWORD, Constants.PasswordORApiKey);

                RequestBody body = RequestBody.create(mediaType, jsonLoginCheck.toString());

                Request requestLogin = new Request.Builder()
                        .url(Constants.singzyBaseURL + "patrons/login")
                        .post(body)
                        .addHeader("accept-language", "en-US,en;q=0.8")
                        .addHeader("content-type", "application/json")
                        .addHeader("accept", "*/*")
                        .build();

                Response responseLogin = client.newCall(requestLogin).execute();

                if (responseLogin.isSuccessful()) {
                    final String ress = responseLogin.body().string();
                    final String Message = responseLogin.message();

                    Mylogger.getInstance().Logit(TAG + "1", ress);

                    if (Message.equals("OK")) {

                        JSONObject resultLogin = new JSONObject(ress);
                        authID = resultLogin.getString("id").toString();
                        authTTL = resultLogin.getLong("ttl");
                        authCreated = resultLogin.getString("created");
                        authUserID = resultLogin.getString("userId");

                        //  call API for get Identity from signzy to get  identities

                        JSONObject param = new JSONObject();
                        param.put("type", from);
                        param.put("callbackUrl", "http://www.opaper.in/");// need to replace
                        param.put("email", Constants.Email);// need to replace
                        JSONArray jsonArray = new JSONArray();
                        jsonArray.put(params[0]);
                        param.put("images", jsonArray);

                        RequestBody bodyauthi = RequestBody.create(mediaType, param.toString());

                        Request requestauthi = new Request.Builder()
                                .url(Constants.singzyBaseURL + "patrons/" + authUserID + "/identities")
                                .post(bodyauthi)
                                .addHeader("accept-language", "en-US,en;q=0.8")
                                .addHeader("content-type", "application/json")
                                .addHeader("accept", "*/*")
                                .addHeader("authorization", authID)
                                .build();

                        Response response2 = client.newCall(requestauthi).execute();

                        if (response2.isSuccessful()) {
                            final String Message1 = response2.message();
                            String tmp = response2.body().string();
                            Mylogger.getInstance().Logit(TAG + "2", tmp);

                            if (Message1.equals("OK")) {

                                JSONObject res = new JSONObject(tmp);

                                identityAccessToken = res.getString("accessToken");
                                identityCallbackUrl = res.getString("callbackUrl");
                                identityEmail = res.getString("email");
                                identityID = res.getString("id");
                                identityPatronId = res.getString("patronId");
                                identityType = res.getString("type");


                                JSONObject pan = new JSONObject();
                                pan.put(Constants.PARAM_SERVICE, "Identity");
                                pan.put(Constants.PARAM_ITEMID, identityID);
                                pan.put(Constants.PARAM_ACCESSTOKEN, identityAccessToken);
                                pan.put(Constants.PARAM_TASK, "autoRecognition");
                                pan.put(Constants.PARAM_ESSENTIALS, panEssentials);

                                Mylogger.getInstance().Logit(TAG + "param", pan.toString());

                                RequestBody bodyAadhar = RequestBody.create(mediaType, pan.toString());
                                Request requestAadhar = new Request.Builder()
                                        .url(Constants.singzyBaseURL + "snoops")
                                        //
                                        .post(bodyAadhar)
                                        .addHeader("accept-language", "en-US,en;q=0.8")
                                        .addHeader("content-type", "application/json")
                                        .addHeader("accept", "*/*")
                                        .build();

                                Response responseAadhar = client.newCall(requestAadhar).execute();

                                myRes = responseAadhar.body().string();
                                panEssentials = null;
                                Mylogger.getInstance().Logit(TAG + "pandata", myRes);
                            }
                        } else {
                            myRes = response2.body().string();
                        }
                    } else {
                        Mylogger.getInstance().Logit(TAG, "Pan admin Auth fail");
                    }

                } else {
                    Mylogger.getInstance().Logit(TAG, "Pan admin Auth fail");
                }


                return myRes;
            } catch (Exception e) {
                e.printStackTrace();
                Mylogger.getInstance().Logit(TAG, e.getMessage().toString());
            }

            return myRes;
        }

        @Override
        protected void onPostExecute(String message) {
            progressDialog.dismiss();
            edit_pan_name.setEnabled(true);
            edit_pan_name_father.setEnabled(true);
            edit_pan_number.setEnabled(true);
            Mylogger.getInstance().Logit(TAG, message);
            try {
                JSONObject jsonObject = new JSONObject(message);

                JSONObject response = jsonObject.getJSONObject("response");
                JSONObject result = response.getJSONObject("result");
                if (result.has("name")) {
                    edit_pan_name.setText(result.getString("name"));
                }

                if (result.has("fatherName")) {
                    edit_pan_name_father.setText(result.getString("fatherName"));
                }

                if (result.has("number")) {
                    edit_pan_number.setText(result.getString("number"));
                }

                setButtonImage();
            } catch (Exception e) {
                //  e.printStackTrace();
                Constants.showAlert(edit_pan_name.getRootView(), "Network error please try again later", false);
            }

        }
    }

    private class UploadFileToServer extends AsyncTask<String, String, String> {
        String line = "{'test':'a'}";

        @Override
        protected void onPreExecute() {
            // setting progress bar to zero
            pd.setMessage("Uploading");
            pd.setCancelable(false);
            pd.show();
            sourceFile = new File(imgURI.getPath());
            totalSize = (int) sourceFile.length();
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            pd.setMessage("Uploading (" + progress[0] + "%)");
            Mylogger.getInstance().Logit(TAG, "" + progress[0]);
            //donut_progress.setProgress(Integer.parseInt(progress[0])); //Updating progress
        }

        @Override
        protected String doInBackground(String... args) {
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = null;
            String fileName = sourceFile.getName();

            try {
                connection = (HttpURLConnection) new URL("http://www.canvascoders.com/nikhil/UploadToServer.php").openConnection();
                connection.setRequestMethod("POST");
                String boundary = "---------------------------boundary";
                String tail = "\r\n--" + boundary + "--\r\n";
                connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                connection.setDoOutput(true);

                String metadataPart = "--" + boundary + "\r\n"
                        + "Content-Disposition: form-data; name=\"metadata\"\r\n\r\n"
                        + "" + "\r\n";

                String fileHeader1 = "--" + boundary + "\r\n"
                        + "Content-Disposition: form-data; name=\"fileToUpload\"; filename=\""
                        + fileName + "\"\r\n"
                        + "Content-Type: application/octet-stream\r\n"
                        + "Content-Transfer-Encoding: binary\r\n";

                long fileLength = sourceFile.length() + tail.length();
                String fileHeader2 = "Content-length: " + fileLength + "\r\n";
                String fileHeader = fileHeader1 + fileHeader2 + "\r\n";
                String stringData = metadataPart + fileHeader;

                long requestLength = stringData.length() + fileLength;
                connection.setRequestProperty("Content-length", "" + requestLength);
                connection.setFixedLengthStreamingMode((int) requestLength);
                connection.connect();

                DataOutputStream out = new DataOutputStream(connection.getOutputStream());
                out.writeBytes(stringData);
                out.flush();

                int progress = 0;
                int bytesRead = 0;
                byte buf[] = new byte[1024];
                BufferedInputStream bufInput = new BufferedInputStream(new FileInputStream(sourceFile));
                while ((bytesRead = bufInput.read(buf)) != -1) {
                    // write output
                    out.write(buf, 0, bytesRead);
                    out.flush();
                    progress += bytesRead; // Here progress is total uploaded bytes

                    publishProgress("" + (int) ((progress * 100) / totalSize)); // sending progress percent to publishProgress
                }

                // Write closing boundary and close stream
                out.writeBytes(tail);
                out.flush();
                out.close();

                // Get server response
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                StringBuilder builder = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                return line;
            } catch (Exception e) {
                Mylogger.getInstance().Logit(TAG, e.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
            return line;
        }

        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
            try {
                if (result != null) {
                    JSONObject jsonObject = new JSONObject(result);
                    Mylogger.getInstance().Logit(TAG, jsonObject.toString());
                } else {
                    Mylogger.getInstance().Logit(TAG, "Null response");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            super.onPostExecute(result);
        }

    }

    public void commanFragmentCallWithoutBackStack(Fragment fragment) {

        Fragment cFragment = fragment;

        if (cFragment != null) {

            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.content_main, cFragment);
            fragmentTransaction.commit();

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        requestPermissionHandler.onRequestPermissionsResult(requestCode, permissions,
                grantResults);
    }

   /* public void deleteFileFromMediaManager(Context context, String path) {
        File file = new File(path);
        file.delete();
        if (file.exists()) {
            try {
                file.getCanonicalFile().delete();

                if (file.exists()) {
                    context.deleteFile(file.getName());
                    Log.e("Deleted File", String.valueOf(file));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }*/

}

