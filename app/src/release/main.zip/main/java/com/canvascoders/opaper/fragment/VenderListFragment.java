package com.canvascoders.opaper.fragment;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.canvascoders.opaper.R;
import com.canvascoders.opaper.activity.DashboardActivity;
import com.canvascoders.opaper.adapters.VendorAdapter;
import com.canvascoders.opaper.api.ApiClient;
import com.canvascoders.opaper.api.ApiInterface;
import com.canvascoders.opaper.Beans.otp.GetOTP;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.utils.Mylogger;
import com.canvascoders.opaper.utils.SessionManager;
import com.canvascoders.opaper.Beans.VendorList;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Callback;

public class VenderListFragment extends Fragment {

    AppCompatRadioButton radio_onboard;
    AppCompatRadioButton radio_inprogress;
    RecyclerView recyclerview;
    VendorAdapter vendorAdapter;
    String TAG = "VendorLis";
    SessionManager sessionManager;
    JSONObject object = new JSONObject();
    ImageView iv_clear_text;
    EditText edit_search_vendor;


    private ArrayList<VendorList> vendorLists = new ArrayList<>();
    private ProgressDialog progressDialog;
    private RadioGroup radio_group;
    private String apiName = "completed-vendors";
    private boolean isonb = true;


    View view;
    Context mcontext;


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_vender_list, container, false);

        mcontext = this.getActivity();

        DashboardActivity.settitle(Constants.TITLE_VENDOR_LIST);

        Initialize();

        return view;
    }


    public void Initialize() {


        edit_search_vendor = view.findViewById(R.id.edt_search_text);
        iv_clear_text = view.findViewById(R.id.iv_clear_text);

        radio_group = (RadioGroup) view.findViewById(R.id.radio_group);
        sessionManager = new SessionManager(mcontext);

        progressDialog = new ProgressDialog(mcontext);
        progressDialog.setMessage("please wait loading onboarded vendors...");

        radio_onboard = (AppCompatRadioButton) view.findViewById(R.id.radio_onboard);
        radio_inprogress = (AppCompatRadioButton) view.findViewById(R.id.radio_onboard);
        recyclerview = (RecyclerView) view.findViewById(R.id.recyclerview);
        recyclerview.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mcontext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        vendorAdapter = new VendorAdapter(VenderListFragment.this, vendorLists);
        vendorAdapter.setInWhichScreen(1);
        recyclerview.setAdapter(vendorAdapter);


        try {
            object.put(Constants.PARAM_TOKEN, sessionManager.getToken());
            object.put(Constants.PARAM_AGENT_ID, sessionManager.getAgentID());
        } catch (JSONException e) {

        }

        /////////////////////////// get onboard vender list/////////////////////////

        apiName = "completed-vendors";
        isonb = true;
        progressDialog.setMessage("please wait loading onboarded vendors...");
        vendorAdapter.setInWhichScreen(1);
        new GetVendorList(object.toString(), apiName).execute();


        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rb = (RadioButton) view.findViewById(checkedId);

                if (rb.getId() == R.id.radio_onboard) {
                    apiName = "completed-vendors";
                    isonb = true;
                    progressDialog.setMessage("please wait loading onboarded vendors...");
                    vendorAdapter.setInWhichScreen(1);
                    edit_search_vendor.setText("");
                    new GetVendorList(object.toString(), apiName).execute();

                } else if (rb.getId() == R.id.radio_inprogress) {
                    apiName = "inprogress-vendors";
                    isonb = false;
                    progressDialog.setMessage("please wait loading in-progress vendors...");
                    vendorAdapter.setInWhichScreen(2);
                    edit_search_vendor.setText("");
                    new GetVendorList(object.toString(), apiName).execute();
                }
            }
        });

        edit_search_vendor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                vendorAdapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        iv_clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_search_vendor.setText("");

            }
        });


    }


    public void sendOTP(final int position) {
        final ProgressDialog mProgressDialog = new ProgressDialog(mcontext);
        mProgressDialog.setMessage("sending OTP to mobile...");
        mProgressDialog.show();
        JsonObject user = new JsonObject();
        user.addProperty(Constants.PARAM_MOBILE_NO, vendorLists.get(position).getMobileNo());
        user.addProperty(Constants.PARAM_TOKEN, sessionManager.getToken());

        Mylogger.getInstance().Logit(TAG, user.toString());
        ApiClient.getClient().create(ApiInterface.class).sendOTP(user).enqueue(new Callback<GetOTP>() {
            @Override
            public void onResponse(Call<GetOTP> call, retrofit2.Response<GetOTP> response) {
                mProgressDialog.dismiss();

                if (response.isSuccessful()) {
                    GetOTP getOTP = response.body();
                    Mylogger.getInstance().Logit(TAG, getOTP.getResponse());
                    if (getOTP.getResponseCode() == 200) {
                        Mylogger.getInstance().Logit(TAG, "OTP is =>" + getOTP.getData().get(0).getOtp().toString());
                        showDialogOTPConfirm(position, getOTP.getData().get(0).getOtp().toString());
                    } else if (getOTP.getResponseCode() == 405) {
                        sessionManager.logoutUser(mcontext);
                    } else {
                        Toast.makeText(mcontext, getOTP.getResponse(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(mcontext, getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetOTP> call, Throwable t) {
                mProgressDialog.dismiss();
                Toast.makeText(mcontext, t.getMessage().toLowerCase(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private void showDialogOTPConfirm(final int position, final String otp) {

        final Dialog dialog = new Dialog(mcontext);
        dialog.setContentView(R.layout.dialog_confirmotp);
        dialog.show();

        final EditText etOtp = dialog.findViewById(R.id.etOtp);
        ImageView ivClose = dialog.findViewById(R.id.ivClose);
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        TextView tvOk = dialog.findViewById(R.id.tvOk);

        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (otp.equalsIgnoreCase(etOtp.getText().toString())) {
                    dialog.dismiss();
                    commanFragmentCallWithBackStack(new VendorDetailsFragment(), vendorLists.get(position));
                } else {
                    Toast.makeText(mcontext, "Invalid OTP ", Toast.LENGTH_LONG).show();
                    etOtp.setText("");
                }

            }
        });
    }

    public class GetVendorList extends AsyncTask<String, Void, String> {

        String jsonReq;
        String apiURL;

        public GetVendorList(String jsonReq, String apiURL) {
            this.jsonReq = jsonReq;
            this.apiURL = apiURL;

            Mylogger.getInstance().Logit("apiURL: ", apiURL);
            Mylogger.getInstance().Logit("jsonReq: ", jsonReq);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            vendorLists.clear();
        }

        @Override
        protected String doInBackground(String[] params) {
            String myRes;
            try {

                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(1000, TimeUnit.MINUTES)
                        .readTimeout(1000, TimeUnit.MINUTES)
                        .writeTimeout(1000, TimeUnit.MINUTES)
                        .build();

                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, jsonReq);
                Request requestLogin = new Request.Builder()
                        .url(Constants.BaseURL + apiURL)
                        .post(body)
                        .build();

                Response responseLogin = client.newCall(requestLogin).execute();
                myRes = responseLogin.body().string();
                Mylogger.getInstance().Logit(TAG + "1", myRes);
                return myRes;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String message) {
            progressDialog.dismiss();
            Mylogger.getInstance().Logit(TAG, message);
            if (message != null) {
                try {

                    Gson gson = new Gson();

                    JSONObject jsonObject = new JSONObject(message);
                    if (jsonObject.has("responseCode")) {
                        if (jsonObject.has("responseCode")) {
                            if (jsonObject.getInt("responseCode") == 200) {

                                JSONArray result = jsonObject.getJSONArray("data");
                                for (int i = 0; i < result.length(); i++) {
                                    JSONObject o = result.getJSONObject(i);

                                    VendorList vendorList = gson.fromJson(o.toString(), VendorList.class);

                                    Log.e("VENDOR", "" + vendorList.getBankDetailUpdationRequired());

                                    VendorList vList = new VendorList();
                                    vList.setId(vendorList.getId());
                                    vList.setAgentId(vendorList.getAgentId());
                                    vList.setMobileNo(vendorList.getMobileNo());
                                    vList.setAadhaarName(vendorList.getAadhaarName());
                                    vList.setAadhaarNo(vendorList.getAadhaarNo());
                                    vList.setAadhaarPincode(vendorList.getAadhaarPincode());
                                    vList.setPanName(vendorList.getPanName());
                                    vList.setPanNo(vendorList.getPanNo());
                                    vList.setShopImage(jsonObject.getString("remote_url") + vendorList.getShopImage());
                                    vList.setStoreName(vendorList.getStoreName());
                                    vList.setMobileVerify(vendorList.getMobileVerify());
                                    vList.setLocationVerify(vendorList.getLocationVerify());
                                    vList.setAadhaarVerify(vendorList.getAadhaarVerify());
                                    vList.setPanVerify(vendorList.getPanVerify());
                                    vList.setChequeVerify(vendorList.getChequeVerify());
                                    vList.setFillDetails(vendorList.getFillDetails());
                                    vList.setUploadFiles(vendorList.getUploadFiles());
                                    vList.setRateSendForApproval(vendorList.getRateSendForApproval());
                                    vList.setAgreement(vendorList.getAgreement());
                                    vList.setGstdeclaration(vendorList.getGstdeclaration());
                                    vList.setVendorSendForApproval(vendorList.getVendorSendForApproval());
                                    vList.setBankDetailUpdationRequired(vendorList.getBankDetailUpdationRequired());
                                    vList.setProccessId(vendorList.getProccessId());
                                    vList.setName(vendorList.getName());
                                    vendorLists.add(vList);
                                }

                            } else if (jsonObject.getInt("responseCode") == 405) {
                                sessionManager.logoutUser(mcontext);
                            }
                            vendorAdapter.notifyDataSetChanged();
                        }

                    } else {
                        sessionManager.logoutUser(mcontext);
                    }
                } catch (
                        JSONException e)

                {
                    e.printStackTrace();
                }
            }
            vendorAdapter.notifyDataSetChanged();
        }
    }

    public void commanFragmentCallWithBackStack(Fragment fragment, VendorList vendorList) {

        Fragment cFragment = fragment;

        Bundle bundle = new Bundle();

        bundle.putSerializable("data", vendorList);

        if (cFragment != null) {

            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragment.setArguments(bundle);
            fragmentTransaction.replace(R.id.content_main, cFragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
    }
}
