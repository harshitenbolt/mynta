package com.canvascoders.opaper.api;


import com.canvascoders.opaper.Beans.EditUserResponse.EditUserResponse;
import com.canvascoders.opaper.Beans.NotificationResponse.NotificattionResponse;
import com.canvascoders.opaper.Beans.PanImageResponse.PanImageResponse;
import com.canvascoders.opaper.Beans.PancardVerifyResponse.CommonResponse;
import com.canvascoders.opaper.Beans.UserDetailTResponse.GetUserDetails;
import com.canvascoders.opaper.Beans.bizdetails.GetUserDetailResponse;
import com.canvascoders.opaper.Beans.dc.GetDC;
import com.canvascoders.opaper.Beans.otp.GetOTP;
import com.canvascoders.opaper.Beans.verifylocation.GetLocationResponse;
import com.canvascoders.opaper.Beans.verifymobile.GetMobileResponse;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

public interface ApiInterface {

    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("auth/agent")
    Call<GetUserDetails> getUserSignin(@Body JsonObject data);

    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("generate-otp")
    Call<GetOTP> sendOTP(@Body JsonObject data);

    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("verify-mobile")
    Call<GetMobileResponse> verifyMobile(@Body JsonObject data);

    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("verify-location")
    Call<GetLocationResponse> verifyLocation(@Body JsonObject data);

    //-----------------------------------------------------------------------------
    @FormUrlEncoded
    @POST("esign-single-invoice1")
    Call<JsonObject> Storeinvoice(@FieldMap() Map<String, String> data);

    //-----------------------------------------------------------------------------
    @FormUrlEncoded
    @POST("nocesign")
    Call<JsonObject> StoreNocDocument(@FieldMap() Map<String, String> data);

    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("esign")
    Call<JsonObject> StoreAgreement(@FieldMap() Map<String, String> data);

    //-----------------------------------------------------------------------------
    @FormUrlEncoded
    @POST("gstesign")
    Call<JsonObject> StoreGstDocument(@FieldMap() Map<String, String> data);

    //-----------------------------------------------------------------------------

//store aadhar
//    @Multipart
//    @POST("verify-aadhaar-card")
//    Call<GetStoreAadharResult> storeAadhar(@Part MultipartBody.Part file, @Part("adhar_card_front") RequestBody adhar_card_front, @Part("description") RequestBody desc, @Part("user_id") RequestBody user_id, @Part("product_id") RequestBody pid, @Part("is_own_product") RequestBody ownp);


    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("submit-details")
    Call<GetUserDetailResponse> submitBizDetails(@Body JsonObject data);
    //-----------------------------------------------------------------------------

    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("rate-update")
    Call<GetUserDetailResponse> submitRate(@Body JsonObject data);
    //-----------------------------------------------------------------------------


    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("get-dc")
    Call<GetDC> getDC(@Body JsonObject data);
    //-----------------------------------------------------------------------------

//    buildernew.addFormDataPart("token", sessionManager.getToken());
//                        buildernew.addFormDataPart("proccess_id", Constants.processID);
//                        buildernew.addFormDataPart("pan", panImagepath.substring(panImagepath.lastIndexOf("/") + 1), RequestBody.create(MEDIA_TYPE_PNG, new File(panImagepath)));
//
//                        buildernew.addFormDataPart("adhar_card_front", aadharImagepathFront.substring(aadharImagepathFront.lastIndexOf("/") + 1), RequestBody.create(MEDIA_TYPE_PNG, new File(aadharImagepathFront)));
//                        buildernew.addFormDataPart("adhar_card_back", aadharImagepathBack.substring(aadharImagepathBack.lastIndexOf("/") + 1), RequestBody.create(MEDIA_TYPE_PNG, new File(aadharImagepathBack)));
//                        buildernew.addFormDataPart("if_shop_act", String.valueOf(inAct));
//                        buildernew.addFormDataPart("shop_image", shopImg.substring(shopImg.lastIndexOf("/") + 1), RequestBody.create(MEDIA_TYPE_PNG, new File(shopImg)));
//
//
//                        for (int i = 0; i < shopActImage.size(); i++) {
//        buildernew.addFormDataPart(shop_act, shopActImage.get(i).substring(shopActImage.get(i).lastIndexOf("/") + 1), RequestBody.create(MEDIA_TYPE_PNG, new File(shopActImage.get(i))));
//    }
//
//                        for (int j = 0; j < cnclChkImage.size(); j++) {
//        buildernew.addFormDataPart("cancelled_cheque[]", cnclChkImage.get(j).substring(cnclChkImage.get(j).lastIndexOf("/") + 1), RequestBody.create(MEDIA_TYPE_PNG, new File(cnclChkImage.get(j))));
//    }


    @POST("get-pancard-ocr-url")
    @Multipart
    Call<PanImageResponse> getPancardOcrUrl(@Part("token") String token,
                                            @Part("proccess_id") String proccess_id,
                                            @Part MultipartBody.Part attachment);

    //-----------------------------------------------------------------------------

    @Multipart
    @POST("verify-aadhaar-card")
    Call<CommonResponse> getstoreAadhar(@PartMap() Map<String, String> data,
                                        @Part MultipartBody.Part aadharcard_front,
                                        @Part MultipartBody.Part aadharcard_back);
    //-----------------------------------------------------------------------------

    @Multipart
    @POST("verify-pan-card")
    Call<CommonResponse> getstorePancard(@PartMap() Map<String, String> data,
                                         @Part MultipartBody.Part pancard);
    //-----------------------------------------------------------------------------

    @Multipart
    @POST("verify-cheque")
    Call<CommonResponse> getstoreCheque(@PartMap() Map<String, String> data,
                                        @Part MultipartBody.Part cheque);
    //-----------------------------------------------------------------------------

    @Multipart
    @POST("shop-act-upload")
    Call<CommonResponse> getstoreDocument(@PartMap() Map<String, String> data,
                                          @Part MultipartBody.Part store_image,
                                          @Part MultipartBody.Part store_image_act);
    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("count-notifications")
    Call<NotificattionResponse> getNotification(@FieldMap() Map<String, String> data);
    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("get-details")
    Call<EditUserResponse> getUserinfo(@FieldMap() Map<String, String> data);
    //-----------------------------------------------------------------------------


    @Headers({"Content-type: application/json", "Accept: */*"})
    @Multipart
    @POST("shop-act-upload")
    Call<CommonResponse> getInvoice(@PartMap() Map<String, String> data,
                                    @Part MultipartBody.Part store_image,
                                    @Part MultipartBody.Part store_image_act);
    //-----------------------------------------------------------------------------


    @FormUrlEncoded
    @POST("esign")
    Call<ResponseBody> Esign(@FieldMap Map<String, String> apiVersionMap);

    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("gstesign")
    Call<ResponseBody> gstEsign(@FieldMap Map<String, String> apiVersionMap);

    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("get-details")
    Call<ResponseBody> getDetails(@FieldMap Map<String, String> apiVersionMap);

    //-----------------------------------------------------------------------------

    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("get-details")
    Call<ResponseBody> getDetails2(@Body JsonObject data);

    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("nocesign")
    Call<ResponseBody> nocEsign(@FieldMap Map<String, String> apiVersionMap);

    //-----------------------------------------------------------------------------

    @FormUrlEncoded
    @POST("get-bank-details-from-ifsc")
    Call<ResponseBody> getBankDetailsFromIfsc(@FieldMap Map<String, String> apiVersionMap);

    //-----------------------------------------------------------------------------


    @Headers({"Content-type: application/json;charset=UTF-8", "Accept: */*", "accept-language: en-US,en;q=0.8"})
    @POST("agreement")
    Call<ResponseBody> getdocumentid(@Header("authorization") String authorization,
                                     @FieldMap Map<String, String> data);
    //-----------------------------------------------------------------------------

    //-----------------------------------------------------------------------------
    @Headers({"Content-type: application/json", "Accept: */*"})
    @POST("api-esign-log")
    Call<ResponseBody> submitSigningLog(@Body JsonObject data);


    @Headers("Content-Type: application/json")
    @POST("store-type")
    Call<ResponseBody> getStoreTypeListing(@Body JsonObject data);

    @Headers("Content-Type: application/json")
    @POST("rate-update")
    Call<ResponseBody> setStoreTypeListing(@Body JsonObject data);

//--------------------------------------------------------------------------------------
@FormUrlEncoded
@POST("esign-single-invoice1")
Call<JsonObject> StoreAddendum(@FieldMap() Map<String, String> data);
//--------------------------------------------------------------------------------------
}
