package com.canvascoders.opaper.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.canvascoders.opaper.Beans.BillList;
import com.canvascoders.opaper.R;
import com.canvascoders.opaper.adapters.BillsAdapter;
import com.canvascoders.opaper.helper.RecyclerViewClickListener;
import com.canvascoders.opaper.helper.RecyclerViewTouchListener;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.utils.Mylogger;
import com.canvascoders.opaper.utils.NetworkConnectivity;
import com.canvascoders.opaper.utils.SessionManager;
import com.canvascoders.opaper.activity.DashboardActivity;
import com.canvascoders.opaper.activity.InvoiceEsignActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class InvoiceMainFragment extends Fragment {
    SessionManager sessionManager;
    String TAG = "InvoiceMain";
    JSONObject object = new JSONObject();
    private BillsAdapter linearAdapter;
    private NetworkConnectivity networkConnectivity;
    private ArrayList<BillList> billLists = new ArrayList<>();
    private ProgressDialog progressDialog;
    private RecyclerView recyclerview;
    private RadioGroup rg_vendor_list;
    private String apiName = "get-invoice1";

    Context mcontext;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_invoice_main, container, false);

        mcontext = this.getActivity();

        DashboardActivity.settitle(Constants.TITLE_INVOICE_LIST);

        intView();

        rg_vendor_list = (RadioGroup) view.findViewById(R.id.activity_course_rg);
        sessionManager = new SessionManager(mcontext);
        progressDialog = new ProgressDialog(mcontext);
        progressDialog.setMessage("please wait loading tax invoice...");


        try {
            object.put(Constants.PARAM_TOKEN, sessionManager.getToken());
            object.put(Constants.PARAM_AGENT_ID, sessionManager.getAgentID());
        } catch (JSONException e) {
        }


        rg_vendor_list.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rb_vendor_list = (RadioButton) view.findViewById(checkedId);

                if (rb_vendor_list.getId() == R.id.rg_pending_vendorlist) {
                    apiName = "get-invoice";
                    progressDialog.setMessage("please wait loading Pending vendor signature...");
                    new GetInvoice1(object.toString(), apiName).execute();

                } else if (rb_vendor_list.getId() == R.id.rg_signatured_vendorlist) {
                    apiName = "get-esign-invoice";
                    progressDialog.setTitle("please wait loading Invoice signed by vendor...");

                    new GetInvoice1(object.toString(), apiName).execute();
                }
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();


        if (!networkConnectivity.isNetworkAvailable()) {

            // Display message in dialog box if you have not internet connection
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(mcontext);
            alertDialogBuilder.setTitle("No Internet Connection");
            alertDialogBuilder.setMessage("You are offline,Please check your internet connection,then try again");
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    getActivity().finish();
                    arg0.dismiss();
                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();


        } else {
            apiName = "get-invoice";
            progressDialog.setMessage("please wait loading Pending vendor signature...");
            new GetInvoice1(object.toString(), apiName).execute();
        }

    }


    private void intView() {
        networkConnectivity = new NetworkConnectivity(mcontext);
        recyclerview = (RecyclerView) view.findViewById(R.id.recyclerview);
        recyclerview.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mcontext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        linearAdapter = new BillsAdapter(billLists);
        recyclerview.setAdapter(linearAdapter);

        recyclerview.addOnItemTouchListener(new RecyclerViewTouchListener(mcontext, recyclerview, new RecyclerViewClickListener() {


            @Override
            public void onClick(View view, final int position) {

//                commanFragmentCallWithBackStack(new InvoiceEsignActivity(), String.valueOf(billLists.get(position).getId()));

                Intent intent = new Intent(getActivity(), InvoiceEsignActivity.class);
                intent.putExtra(Constants.KEY_INVOICE_ID, String.valueOf(billLists.get(position).getId()));
                startActivity(intent);
            }


            @Override
            public void onLongClick(View view, final int position) {

            }
        }

        ));

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            getActivity().finish(); // close this activity and return to preview activity (if there is any)
        }
        return super.onOptionsItemSelected(item);
    }


    public class GetInvoice1 extends AsyncTask<String, Void, String> {

        String jsonReq;
        String apinumber;

        public GetInvoice1(String jsonReq, String apinumber) {
            this.jsonReq = jsonReq;
            this.apinumber = apinumber;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            billLists.clear();
        }

        @Override
        protected String doInBackground(String[] params) {
            String myRes;
            try {
                OkHttpClient client = new OkHttpClient();
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, jsonReq);
                Request requestLogin = new Request.Builder()
                        .url(Constants.BaseURL + apinumber)
                        .post(body)
                        .build();

                Response responseLogin = client.newCall(requestLogin).execute();
                myRes = responseLogin.body().string();
                Mylogger.getInstance().Logit(TAG + "1", myRes);
                return myRes;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String message) {
            progressDialog.dismiss();
            try {
                JSONObject jsonObject = new JSONObject(message);
                Mylogger.getInstance().Logit(TAG, message);
                if (jsonObject.getInt("responseCode") == 200) {

                    JSONArray result = jsonObject.getJSONArray("data");
                    if (result.length() > 0) {
                        ImageView m = (ImageView) view.findViewById(R.id.imgnodata);
                        m.setVisibility(View.GONE);
                    } else {
                        ImageView m = (ImageView) view.findViewById(R.id.imgnodata);
                        m.setVisibility(View.VISIBLE);
                    }
                    for (int i = 0; i < result.length(); i++) {
                        JSONObject o = result.getJSONObject(i);

                        Integer id;
                        Integer invoice_status;
                        String proccess_id;
                        String store_name;
                        String bill_period;
                        String dc;
                        String store_address;
                        String amt;
                        String mobile_no;
                        String updated_at;
                        String vendor_id;


                        id = o.getInt("id");
                        proccess_id = o.getString("proccess_id");
                        store_name = o.getString("store_name");
                        if (o.isNull("bill_period")) {
                            bill_period = "";
                        } else {
                            bill_period = o.getString("bill_period");
                        }
                        dc = o.getString("dc");
                        store_address = o.getString("store_address");
                        amt = "0";
                        mobile_no = o.getString("mobile_no");
                        updated_at = o.getString("updated_at");
                        vendor_id = o.getString("vendor_id");
                        invoice_status = 0;

                        billLists.add(new BillList(id, proccess_id, store_name, bill_period, dc, store_address, amt, mobile_no, updated_at, invoice_status, vendor_id));
                    }
                    linearAdapter.notifyDataSetChanged();
                } else {
                    ImageView m = (ImageView) view.findViewById(R.id.imgnodata);
                    m.setVisibility(View.VISIBLE);
                    Toast.makeText(mcontext, jsonObject.getString("response").toLowerCase(), Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    public void commanFragmentCallWithBackStack(Fragment fragment, String invoice_id) {

        Fragment cFragment = fragment;

        Bundle bundle = new Bundle();

        bundle.putSerializable(Constants.KEY_INVOICE_ID, invoice_id);

        if (cFragment != null) {

            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragment.setArguments(bundle);
            fragmentTransaction.replace(R.id.content_main, cFragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
    }
}
