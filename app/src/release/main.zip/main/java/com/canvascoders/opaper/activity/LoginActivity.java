package com.canvascoders.opaper.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.canvascoders.opaper.R;
import com.canvascoders.opaper.api.ApiClient;
import com.canvascoders.opaper.api.ApiInterface;
import com.canvascoders.opaper.Beans.UserDetailTResponse.GetUserDetails;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.utils.Mylogger;
import com.canvascoders.opaper.utils.RequestPermissionHandler;
import com.canvascoders.opaper.utils.SessionManager;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.canvascoders.opaper.utils.Constants.showAlert;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private String TAG = "LoginActivity";
    private EditText edt_email_id, edt_password;
    private Button btn_login;
    private ProgressDialog mProgressDialog;
    private SessionManager sessionManager;
    RequestPermissionHandler requestPermissionHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sessionManager = new SessionManager(LoginActivity.this);
        initView();
    }

    private void initView() {

        requestPermissionHandler = new RequestPermissionHandler();

        mProgressDialog = new ProgressDialog(LoginActivity.this);
        mProgressDialog.setMessage("Please wait authenticating store executive");

        edt_email_id = (EditText) findViewById(R.id.edt_email);
        edt_password = (EditText) findViewById(R.id.edit_password);
        btn_login = (Button) findViewById(R.id.btn_login);

        edt_email_id.setTextSize(TypedValue.COMPLEX_UNIT_PX, 11f * AppApplication.dip);
        edt_password.setTextSize(TypedValue.COMPLEX_UNIT_PX, 11f * AppApplication.dip);
        btn_login.setTextSize(TypedValue.COMPLEX_UNIT_PX, 14f * AppApplication.dip);

        btn_login.setOnClickListener(this);
    }

    private boolean isValid(View v) {
        if (edt_email_id.getText().toString().length() == 0) {
            //_editTextMobile.setError("Provide Username");
            showAlert(v, "Provide Email", false);
            edt_email_id.requestFocus();
            return false;
        }
        if (!Constants.isEmailValid(edt_email_id.getText().toString())) {
            //_editTextMobile.setError("Provide Valid email");
            showAlert(v, "Provide Valid email", false);
            edt_email_id.requestFocus();
            return false;
        }
        if (edt_password.getText().toString().length() == 0) {
            //edt_password.setError("Provide Password");
            showAlert(v, "Provide Password", false);
            edt_password.requestFocus();
            return false;
        }


        return true;
    }

    public void setLogin(final View v) {

        String FCMID = null;

        mProgressDialog.show();
        JsonObject user = new JsonObject();
        user.addProperty(Constants.PARAM_EMAIL, edt_email_id.getText().toString().trim());
        user.addProperty(Constants.PARAM_PASSWORD, edt_password.getText().toString().trim());
        user.addProperty(Constants.PARAM_FCM_ID, sessionManager.getData(Constants.KEY_FCM_ID));

        Log.e("FCMID", "FCMID" + sessionManager.getData(Constants.KEY_FCM_ID));

        ApiClient.getClient().create(ApiInterface.class).getUserSignin(user).enqueue(new Callback<GetUserDetails>() {
            @Override
            public void onResponse(Call<GetUserDetails> call, Response<GetUserDetails> response) {
                mProgressDialog.dismiss();
                if (response.isSuccessful()) {
                    GetUserDetails getUserDetails = response.body();
                    Mylogger.getInstance().Logit(TAG, getUserDetails.getResponse());
                    if (getUserDetails.getResponseCode() == 200) {
                        //TODO  manage session here later
                        String agent_id;
                        String token;
                        String name;
                        String email;
                        String rh_id;
                        String emp_id;
                        String mobile;
                        String city;

                        agent_id = String.valueOf(getUserDetails.getData().get(0).getAgentId());
                        token = String.valueOf(getUserDetails.getData().get(0).getToken());
                        email = String.valueOf(getUserDetails.getData().get(0).getEmail());
                        name = String.valueOf(getUserDetails.getData().get(0).getName());
                        rh_id = String.valueOf(getUserDetails.getData().get(0).getRhId());
                        emp_id = getUserDetails.getData().get(0).getEmpId();
                        mobile = getUserDetails.getData().get(0).getMobile();
                        city = getUserDetails.getData().get(0).getCity();

                        sessionManager.createLogin(agent_id, token, name, email, rh_id, emp_id, mobile, city);

                        Intent i = new Intent(LoginActivity.this, DashboardActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        showAlert(v, response.body().getResponse(), false);
                    }
                } else {
                    showAlert(v, getString(R.string.something_went_wrong), false);
                }
            }

            @Override
            public void onFailure(Call<GetUserDetails> call, Throwable t) {
                mProgressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage().toLowerCase(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_login) {


            getPermitionGrant(v);

        }
    }


    private void getPermitionGrant(View v) {
        requestPermissionHandler.requestPermission(this, new String[]{
                Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION
        }, 123, new RequestPermissionHandler.RequestPermissionListener() {
            @Override
            public void onSuccess() {

                if (isValid(v)) {
                    if (AppApplication.networkConnectivity.isNetworkAvailable()) {
                        setLogin(v);
                    } else {
                        Constants.ShowNoInternet(LoginActivity.this);
                    }
                }

            }

            @Override
            public void onFailed() {

                Toast.makeText(getApplicationContext(), "request permission failed", Toast.LENGTH_SHORT).show();

            }
        });

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        requestPermissionHandler.onRequestPermissionsResult(requestCode, permissions,
                grantResults);
    }

}
