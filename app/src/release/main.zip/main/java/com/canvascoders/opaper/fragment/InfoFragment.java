package com.canvascoders.opaper.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.canvascoders.opaper.Beans.bizdetails.GetUserDetailResponse;
import com.canvascoders.opaper.Beans.dc.DC;
import com.canvascoders.opaper.Beans.dc.GetDC;
import com.canvascoders.opaper.R;
import com.canvascoders.opaper.api.ApiClient;
import com.canvascoders.opaper.api.ApiInterface;
import com.canvascoders.opaper.utils.Constants;
import com.canvascoders.opaper.utils.Mylogger;
import com.canvascoders.opaper.utils.SessionManager;
import com.canvascoders.opaper.activity.AppApplication;
import com.canvascoders.opaper.activity.OTPActivity;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.canvascoders.opaper.utils.Constants.showAlert;

public class InfoFragment extends Fragment implements View.OnClickListener {

    private EditText edit_fathername, edit_email, edit_storename, edit_storeaddress, edit_pincode, edit_gstn, edit_city, edit_state, edit_licenceno;
    private Toolbar toolbar;
    private SwitchCompat switchGst;
    private String TAG = "InfoFragment";
    private ProgressDialog mProgressDialog;
    private SessionManager sessionManager;
    private Button btn_next;
    private String isgsttn = "no";
    private ArrayList<String> dcLists = new ArrayList<>();
    private Spinner dc;
    String str_process_id;
    Context mcontext;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_info, container, false);

        mcontext = this.getActivity();

        sessionManager = new SessionManager(mcontext);
        str_process_id = sessionManager.getData(Constants.KEY_PROCESS_ID);

        OTPActivity.settitle(Constants.TITLE_VENDOR_DETAIL_MENSA);

        initView();
        return view;
    }

    private void initView() {
        dc = (Spinner) view.findViewById(R.id.dc);
        btn_next = view.findViewById(R.id.btn_next);
        mProgressDialog = new ProgressDialog(mcontext);
        mProgressDialog.setMessage("Please wait submitting vendor details");
        edit_fathername = (EditText) view.findViewById(R.id.edit_fathername);
        edit_email = (EditText) view.findViewById(R.id.edit_email);
        edit_storename = (EditText) view.findViewById(R.id.edit_storename);
        edit_storeaddress = (EditText) view.findViewById(R.id.edit_storeaddress);
        edit_pincode = (EditText) view.findViewById(R.id.edit_pincode);
        edit_gstn = (EditText) view.findViewById(R.id.edit_gstn);
        switchGst = (SwitchCompat) view.findViewById(R.id.switch_gst);
        edit_city = (EditText) view.findViewById(R.id.edit_city);
        edit_state = (EditText) view.findViewById(R.id.edit_state);
        edit_licenceno = (EditText) view.findViewById(R.id.edit_licenceno);

        switchGst.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Mylogger.getInstance().Logit(TAG, "" + isChecked);
                edit_gstn.setEnabled(isChecked);
                if (isChecked) {
                    isgsttn = "yes";
                } else {
                    isgsttn = "no";
                    edit_gstn.setHint("GSTN");
                }
            }
        });
        btn_next.setOnClickListener(this);
        edit_pincode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 6) {
                    addDC(s.toString());
                }
            }
        });
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_next) {
            Constants.hideKeyboardwithoutPopulate(getActivity());


            if (AppApplication.networkConnectivity.isNetworkAvailable()) {
                if (validation()) bizDetailsSubmit(v);
            } else {
                Constants.ShowNoInternet(getActivity());
            }

        }
    }

    private boolean validation() {
        if (TextUtils.isEmpty(edit_email.getText().toString())) {
            edit_email.requestFocus();
            showMSG(false, "Provide Email");
            return false;
        }
        if (!Constants.isEmailValid(edit_email.getText().toString())) {
            //_editTextMobile.setError("Provide Valid email");
            showMSG(false, "Provide Valid Email");
            edit_email.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(edit_storename.getText().toString())) {
            edit_storename.requestFocus();
            showMSG(false, "Provide Store name");
            return false;
        }
        if (TextUtils.isEmpty(edit_storeaddress.getText().toString())) {
            edit_storeaddress.requestFocus();
            showMSG(false, "Provide Store address");
            return false;
        }
        if (TextUtils.isEmpty(edit_pincode.getText().toString())) {
            edit_pincode.requestFocus();
            showMSG(false, "Provide Pincode");
            return false;
        }
        if (isgsttn.equalsIgnoreCase("yes")) {
            if (TextUtils.isEmpty(edit_gstn.getText().toString())) {
                edit_gstn.requestFocus();
                showMSG(false, "Provide GSTN number");
                return false;
            }
        }
        Matcher gstMatcher = Constants.GST_PATTERN.matcher(edit_gstn.getText().toString());
        if (isgsttn.equalsIgnoreCase("yes") && !gstMatcher.matches()) {
            showMSG(false, "Provide Valid GST No.");
            return false;
        }


        if (TextUtils.isEmpty(edit_licenceno.getText().toString())) {
            edit_licenceno.requestFocus();
            showMSG(false, "Provide Licence number");
            return false;
        }

        return true;
    }

    private void showMSG(boolean b, String msg) {
        final TextView txt_show_msg_sucess = (TextView) view.findViewById(R.id.txt_show_msg_sucess);
        final TextView txt_show_msg_fail = (TextView) view.findViewById(R.id.txt_show_msg_fail);
        txt_show_msg_sucess.setVisibility(View.GONE);
        txt_show_msg_fail.setVisibility(View.GONE);
        if (b) {
            txt_show_msg_sucess.setText(msg);
            txt_show_msg_sucess.setVisibility(View.VISIBLE);
        } else {
            txt_show_msg_fail.setText(msg);
            txt_show_msg_fail.setVisibility(View.VISIBLE);
        }

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                txt_show_msg_sucess.setVisibility(View.GONE);
                txt_show_msg_fail.setVisibility(View.GONE);
            }
        }, 2000);
    }


    public void bizDetailsSubmit(final View v) {

        mProgressDialog.show();
        JsonObject user = new JsonObject();
        user.addProperty(Constants.PARAM_PROCESS_ID, str_process_id);
        user.addProperty(Constants.PARAM_AGENT_ID, sessionManager.getAgentID());
        user.addProperty(Constants.PARAM_TOKEN, sessionManager.getToken());
        user.addProperty(Constants.PARAM_FATHER_NAME, "" + edit_fathername.getText());
        user.addProperty(Constants.PARAM_EMAIL, "" + edit_email.getText());
        user.addProperty(Constants.PARAM_IF_GST, isgsttn);
        user.addProperty(Constants.PARAM_GSTN, "" + edit_gstn.getText());
        user.addProperty(Constants.PARAM_PINCODE, "" + edit_pincode.getText());
        user.addProperty(Constants.PARAM_DC, "" + dc.getSelectedItem());
        user.addProperty(Constants.PARAM_STATE, "" + edit_state.getText());
        user.addProperty(Constants.PARAM_CITY, "" + edit_city.getText());
        user.addProperty(Constants.PARAM_STORE_NAME, "" + edit_storename.getText());
        user.addProperty(Constants.PARAM_STORE_ADDRESS, "" + edit_storeaddress.getText());
        user.addProperty(Constants.PARAM_LICENCE_NO, "" + edit_licenceno.getText());

        Log.e("User Date", "Edit info" + user);
        Log.e("User Date", "Edit info" + str_process_id + "   " + sessionManager.getAgentID());


        ApiClient.getClient().create(ApiInterface.class).submitBizDetails(user).enqueue(new Callback<GetUserDetailResponse>() {
            @Override
            public void onResponse(Call<GetUserDetailResponse> call, Response<GetUserDetailResponse> response) {
                mProgressDialog.dismiss();
                if (response.isSuccessful()) {
                    GetUserDetailResponse getUserDetailResponse = response.body();
                    Mylogger.getInstance().Logit(TAG, getUserDetailResponse.getResponse());
                    if (getUserDetailResponse.getResponseCode() == 200) {
                        Mylogger.getInstance().Logit(TAG, "" + getUserDetailResponse.getData().get(0).getProccessId());

                        commanFragmentCallWithoutBackStack(new DocUploadFragment());


                    } else {
                        showAlert(v, getUserDetailResponse.getResponse(), false);
                        if (getUserDetailResponse.getResponseCode() == 405) {
                            sessionManager.logoutUser(mcontext);
                        }
                    }
                } else {
                    showAlert(v, getString(R.string.something_went_wrong), false);
                }
            }

            @Override
            public void onFailure(Call<GetUserDetailResponse> call, Throwable t) {
                mProgressDialog.dismiss();
                Toast.makeText(mcontext, t.getMessage().toLowerCase(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private void addDC(String pcode) {
        // state is DC and DC is state

        dcLists.clear();
        mProgressDialog.show();

        JsonObject user = new JsonObject();
        user.addProperty(Constants.PARAM_TOKEN, sessionManager.getToken());
        user.addProperty(Constants.PARAM_PINCODE, pcode);
        ApiClient.getClient().create(ApiInterface.class).getDC(user).enqueue(new Callback<GetDC>() {
            @Override
            public void onResponse(Call<GetDC> call, Response<GetDC> response) {
                mProgressDialog.dismiss();
                if (response.isSuccessful()) {
                    GetDC getUserDetails = response.body();
                    Mylogger.getInstance().Logit(TAG, getUserDetails.getResponse());
                    if (getUserDetails.getResponseCode() == 200) {

                        for (int i = 0; i < getUserDetails.getData().size(); i++) {
                            for (DC dc : getUserDetails.getData().get(i).getDc()) {
                                dcLists.add(dc.getDc());
                            }
                            edit_state.setText(getUserDetails.getData().get(i).getState());
                            edit_city.setText(getUserDetails.getData().get(i).getCity());
                        }

                        CustomAdapter<String> spinnerArrayAdapter = new CustomAdapter<String>(mcontext, android.R.layout.simple_spinner_item, dcLists);
                        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        dc.setAdapter(spinnerArrayAdapter);
                        dc.setSelection(0);

                    } else if (getUserDetails.getResponseCode() == 405) {
                        sessionManager.logoutUser(mcontext);
                    } else {
                        Toast.makeText(mcontext, getUserDetails.getResponse(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetDC> call, Throwable t) {
                mProgressDialog.dismiss();
                Toast.makeText(mcontext, t.getMessage().toLowerCase(), Toast.LENGTH_LONG).show();
            }
        });

    }

    class CustomAdapter<T> extends ArrayAdapter<T> {
        public CustomAdapter(Context context, int textViewResourceId,
                             List<T> objects) {
            super(context, textViewResourceId, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = super.getView(position, convertView, parent);
            if (view instanceof TextView) {
                ((TextView) view).setTextSize(12);
                Typeface typeface = ResourcesCompat.getFont(parent.getContext(), R.font.rb_regular);
                ((TextView) view).setTypeface(typeface);
            }
            return view;
        }
    }

    public void commanFragmentCallWithoutBackStack(Fragment fragment) {

        Fragment cFragment = fragment;

        if (cFragment != null) {

            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.content_main, cFragment);
            fragmentTransaction.commit();

        }
    }
}



