package com.canvascoders.opaper.Beans.NotificationResponse;

public class NotificattionResponse {


    private String response;

    private Integer count;

    private String isupdateavailable;

    private Integer version;

    public String getResponse ()
    {
        return response;
    }

    public void setResponse (String response)
    {
        this.response = response;
    }

    public Integer getCount ()
    {
        return count;
    }

    public void setCount (Integer count)
    {
        this.count = count;
    }

    public String getIsupdateavailable ()
    {
        return isupdateavailable;
    }

    public void setIsupdateavailable (String isupdateavailable)
    {
        this.isupdateavailable = isupdateavailable;
    }

    public Integer getVersion ()
    {
        return version;
    }

    public void setVersion (Integer version)
    {
        this.version = version;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [response = "+response+", count = "+count+", isupdateavailable = "+isupdateavailable+", version = "+version+"]";
    }
}
