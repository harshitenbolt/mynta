package com.canvascoders.opaper.Beans.PanImageResponse;

/**
 * Created by Piyush on 3/6/2018.
 */

public class PanImageDatum {

    String pan_url;

    public String getPan_url() {
        return pan_url;
    }

    public void setPan_url(String pan_url) {
        this.pan_url = pan_url;
    }
}
