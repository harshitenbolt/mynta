package com.canvascoders.opaper.utils;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Build;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.TextView;

import com.canvascoders.opaper.Beans.BillList;
import com.canvascoders.opaper.R;
import com.canvascoders.opaper.activity.AppApplication;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Constants {

    //-------------------------------------------------------------------------
    public final static int APP_VERSION = 14; //need to set 13 here befor apk sent on last update before 942018 @ 12 version
    //-------------------------------------------------------------------------


    public final static String FORMAT = "format";
    public final static String CONTENT = "content";
    public static final String KEY_DOCUMENT_ID = "document_id";
    public static final String KEY_STORES = "stores";

    //Whole App Base URL for API manage n Call

    public static String BaseURL = "http://139.59.94.135/api3/";  // test server 3

    //    public static String BaseURL = "http://139.59.94.135/api2/";  // test server 2
    //        public static String BaseURL = "http://159.89.170.91/api2/";  // live new @2652018
    public static String AADHAR_VID_URL = "https://resident.uidai.gov.in/web/resident/vidgeneration";
    //public static String BaseURL = "https://myntraopaper.opaper.in/api/";  // live
    public static String IMGEFORDIGIO = "http://139.59.59.181/app_logo.png";  // Image for Digio

    //Static Fixde Values
    public static final int VIEW_TYPE_ITEM = 0;
    public static final int VIEW_TYPE_ADMIN = 1;
    public static final int VIEW_TYPE_ADMIN2 = 11;
    public static final int VIEW_TYPE_LOADING = 99;
    //
    public static String UserName = "99filings";
    public static String PasswordORApiKey = "MEXTCHw3fOW5dduuvSiWHREwOGIwaPfYWjJgiOuC";
    public static String Email = "admin@signzy.com";

//    public static String DIGIO_CLIENT_ID = "AIJZGP76FTA5PGED1RLPOFHXQF5FAKID"; // none production
//    public static String DIGIO_CLIENT_SECRET = "AHMJWDE2VTIIMHPZ64QA5QLETI1YPM9Q";    // none production

    //For Digio Client_id and Secret Code live
    public static String DIGIO_CLIENT_ID = "AIFKNWV8B3OSU21ABJQTGSZ5GSJOIVYY";
    public static String DIGIO_CLIENT_SECRET = "ZMQG9SCZ576KLDY4EQRH53CQ94C84P3N";
    public static String DIGIO_BASE_URL = "https://api.digio.in/";

    public static Pattern PAN_PATTERN = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");

    public static Pattern GST_PATTERN = Pattern.compile("[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}");
    //    "[0-9]{2}[A-Z,a-z]{5}[0-9]{4}[A-Z,a-z]{1}[0-9A-Z,a-z]{1}[z,Z]{1}[0-9A-Z,a-z]{1}"

    //OTP Tmeplate for SMS
    public static String OTP_TEMPLATE = "One Time Password is ";
    public static String OTP_TEMPLATE1 = " ,Please use this OTP to complete the transaction. This is usable once and expire in 10 minutes. Please do not share this with anyone.";
    //SMS Getway
    public static String SMSSPI = "https://control.msg91.com/api/sendhttp.php?";  // msg
    public static String authkey = "127127AlTqjnGW757f20a0e";//Your authentication key for sms
    public static String sendrid = "Enbolt";
    public static String route = "4";

    public static String IFSC_FIND = "https://api.techm.co.in/api/v1/ifsc/";  // msg
    public static String PINCODE_API = "http://postalpincode.in/api/pincode/";  // msg

    //SingzyBaseURL for Aadhar and PAN Validation
    public static String singzyBaseURL = "https://signzy.tech/api/v2/";  //

    public static String GET_BANK_DETAILS = BaseURL + "get-bank-details";
    public static String BANK_DETAILS_UPDATION = BaseURL + "bank-details-updation";

    public static BillList billList = new BillList();


    //Key for Session Store
    public static String KEY_AGENTID = "userid";
    public static String KEY_AGENT_ID = "agent_id";
    public static String KEY_TOKEN = "tkn";
    public static String KEY_EMAIL = "email";
    public static String KEY_NAME = "name";
    public static String KEY_AADHAR_NAME = "uid_name";
    public static String KEY_RH_ID = "rh_id";
    public static String KEY_EMP_ID = "emp_id";

    public static String KEY_EMP_MOBILE = "mobile";
    public static String KEY_EMP_CITY = "city";
    public static String KEY_DC = "dc";
    public static String KEY_PASSWORD = "password";
    public static String KEY_FCM_ID = "FCMID";
    public static String KEY_PROCESS_ID = "proccess_id";
    public static String KEY_UID = "uid";
    public static String KEY_PINCODE = "pincode";
    public static String KEY_YEAR = "year";
    public static String KEY_INVOICE_ID = "invoice_id";
    public static String KEY_EDIT_DETAIL = "edit_detail";

    //-------------------------

    //For Vendor Mobile info
    public static String KEY_VENDOR_MOBILE = "vendor_mobile";

    //all api parameter
    public static String PARAM_EMAIL = "email";
    public static String PARAM_PASSWORD = "password";
    public static String PARAM_FCM_ID = "fcm_id";
    public static String PARAM_TOKEN = "token";
    public static String PARAM_AGENT_ID = "agent_id";
    public static String PARAM_MOBILE_NO = "mobile_no";
    public static String PARAM_PROCESS_ID = "proccess_id";
    public static String PARAM_UID = "uid";
    public static String PARAM_NAME = "name";
    public static String PARAM_YEAR_OF_BIRTH = "yob";
    public static String PARAM_PINCODE = "pincode";
    public static String PARAM_AADHAR_FRONT = "adhar_card_front";
    public static String PARAM_AADHAR_BACK = "adhar_card_back";
    public static String PARAM_ESIGN_URL = "esign_url";
    public static String PARAM_IFSC = "ifsc";
    public static String PARAM_AC_NAME = "ac_name";
    public static String PARAM_BANK_AC = "bank_ac";
    public static String PARAM_CANCELLED_CHEQUE = "cancelled_cheque";
    public static String PARAM_IF_SHOP_ACT = "if_shop_act";
    public static String PARAM_SHOP_IMAGE = "shop_image";
    public static String PARAM_FATHER_NAME = "father_name";
    public static String PARAM_IF_GST = "if_gst";
    public static String PARAM_GSTN = "gstn";
    public static String PARAM_STATE = "state";
    public static String PARAM_CITY = "city";
    public static String PARAM_DC = "dc";
    public static String PARAM_STORE_NAME = "store_name";
    public static String PARAM_STORE_ADDRESS = "store_address";
    public static String PARAM_LICENCE_NO = "license_no";
    public static String PARAM_INVOICE_ID = "invoice_id";
    public static String PARAM_ENBOLT_ID = "enbolt_id";
    public static String PARAM_LONGITUDE = "longitude";
    public static String PARAM_LATITUDE = "latitude";
    public static String PARAM_PAN_NO = "pan_no";
    public static String PARAM_PAN_NAME = "pan_name";
    public static String PARAM_PAN_CARD_FRONT = "pan_card_front";
    public static String PARAM_RATE = "rate";
    public static String PARAM_USER_NAME = "username";
    public static String PARAM_REQUEST_ID = "request_id";
    public static String PARAM_EDIT_DETAIL = "edit_detail";


    public static String PARAM_IDENTIFIRE = "identifier";
    public static String PARAM_AADHAR_ID = "aadhaar_id";
    public static String PARAM_VID = "vid";
    public static String PARAM_FILE_NAME = "file_name";
    public static String PARAM_COMMENT = "comment";
    public static String PARAM_SIGNERS = "signers";
    public static String PARAM_FILE_DATA = "file_data";
    public static String PARAM_EXPIRE_IN_DAY = "expire_in_days";
    public static String PARAM_DISPLAY_ON_PAGE = "display_on_page";
    public static String PARAM_NOTIFY_SIGNERS = "notify_signers";

    public static String PARAM_SERVICE = "service";
    public static String PARAM_ITEMID = "itemId";
    public static String PARAM_ACCESSTOKEN = "accessToken";
    public static String PARAM_TASK = "task";
    public static String PARAM_ESSENTIALS = "essentials";


    // set title
    public static String TITLE_DASHBOARD = "Dashboard";
    public static String TITLE_MOBILE_AUTH = "Mobile Authentication";
    public static String TITLE_SCANNER = "QR Code Scan";
    public static String TITLE_AGREEMENT = "Agreement Details";
    public static String TITLE_CHEQUE = "Cheque Verification";
    public static String TITLE_DOCUMENT = "Document Verification";
    public static String TITLE_GST_DETAIL = "GST Details";
    public static String TITLE_VENDOR_DETAIL_MENSA = "MENSA Vendor Details";
    public static String TITLE_INVOICE_DETAIL = "Invoice Detail";
    public static String TITLE_INVOICE_LIST = "Invoice List";
    public static String TITLE_LOCATION = "Location";
    public static String TITLE_NOC_DETAIL = "Noc Details";
    public static String TITLE_NOTIFICATION = "Notification";
    public static String TITLE_PAN_CARD_VERIFICATION = "PAN Card Verification";
    public static String TITLE_PROFILE = "Profile";
    public static String TITLE_RATE_UPDATE = "Rate Update";
    public static String TITLE_REPORT = "Reports";
    public static String TITLE_VENDOR_LIST = "Vendor List";
    public static String TITLE_VENDOR_DETAIL = "Vendor Details";


    public static boolean isEmailValid(String email) {
        boolean isValid = false;
        //String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        String expression =
                "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                        + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                        + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                        + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                        + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                        + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

        //String expression = "^((([a-z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+(\\.([a-z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(\\\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.)+(([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.?$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static void showAlert(View v, String msg, boolean isValid) {
        Snackbar snackbar = Snackbar.make(v, msg, Snackbar.LENGTH_LONG);
        snackbar.setActionTextColor(Color.WHITE);
        View sbView = snackbar.getView();
        if (isValid) {
            sbView.setBackgroundColor(ContextCompat.getColor(AppApplication.getInstance(), R.color.colorPrimary));
        } else {
            sbView.setBackgroundColor(ContextCompat.getColor(AppApplication.getInstance(), R.color.colorRed));
        }
        TextView tv = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        } else {
            tv.setGravity(Gravity.CENTER_HORIZONTAL);
        }
        tv.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public static void ShowNoInternet(final Context context) {
        // Display message in dialog box if you have not internet connection
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle("No Internet Connection");
        alertDialogBuilder.setMessage("You are offline,Please check your internet connection,then try again");
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                //appCompatActivity.finish();
                arg0.dismiss();


            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    public static void hideKeyboardwithoutPopulate(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }

    // url = file path or whatever suitable URL you want.
    public static String getMimeType(String url) {
        String type = "application/octact-stream";
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }


}
