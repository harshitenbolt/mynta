package com.canvascoders.opaper.utils;

public interface OnTaskCompleted{
	void onTaskCompleted(String result);
}
