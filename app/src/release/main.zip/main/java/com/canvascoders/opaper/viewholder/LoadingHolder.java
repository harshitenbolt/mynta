package com.canvascoders.opaper.viewholder;


import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by Nikhil on 1/3/2017.
 */
public class LoadingHolder extends RecyclerView.ViewHolder {

    public LoadingHolder(View itemView) {
        super(itemView);
    }
}
